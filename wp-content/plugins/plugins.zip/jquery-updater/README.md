jQuery-Updater
==============

jQuery Updater for WordPress




[![Build Status](https://travis-ci.org/Ramoonus/jQuery-Updater.png?branch=master)](https://travis-ci.org/Ramoonus/jQuery-Updater)