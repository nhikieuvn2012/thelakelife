<script type="text/javascript">
  var __<?php echo $namespace; ?>_count_url = "<?php echo $count_url; ?>";
</script>
